USE [TaxywinSecure1]
GO

DECLARE @year INT
SET @year=2018

;with SubmissionStatus as
(
select c.Clientid
	,fbis.strStatus as SubmissionStatus
	,fbi.dtSubmitted as DateSubmitted
	,fbi.strIRMark

from Client c

inner join fbiSubmissions fbi on fbi.lclientid = c.clientid
inner join fbiStatusRef fbis on fbis.lid = fbi.lstatusid

where fbi.nYear = @year

)

SELECT
	
	c.refcode AS [Client Code]
	,c.Surname
	,c.Firstnames
	,tf.[year] AS [Tax Year]
	,tf.dtPrinted  AS [Last Date Printed]
	,tf.DateFinalised [Date Finalised]
	,ss.SubmissionStatus
	,ss.DateSubmitted
	,ss.strIRMark AS [IR Mark When Submitted]
	,tf.bAmendedReturn AS [Amended Return]
	,tf.dtAmendmentStarted AS [Date Amendment Started]

FROM

	Client c

INNER JOIN taxform tf WITH (NOLOCK) ON tf.clientid = c.clientid
LEFT JOIN SubmissionStatus ss WITH (NOLOCK) ON ss.clientid = c.clientid

WHERE

	tf.[year] = @year

ORDER BY

	c.refcode