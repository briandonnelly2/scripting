USE [TaxywinCOE]
GO

DECLARE @year INT
SET @year=2018

SELECT

 c.refcode [Client Code]
,c.SURNAME [Surname / Pship Name]
,isnull (c.FIRSTNAMES,0) [First Name(s)]
,c.TaxRef [Tax Reference]
,c.CLIENTTYPE [Type]
,sub.strUser [User Name]
,sub.dtSubmitted [Date and Time]
,sub.nYear [Tax Year]
,subref.strStatus [Status]
,gc.GroupId [Access Group]


FROM

 client c

LEFT JOIN FBISubmissions sub on sub.lClientID = c.clientid
LEFT JOIN GroupClient gc on gc.clientid = c.clientid
LEFT JOIN FBIStatusRef subref on subref.lID = sub.lStatusID

WHERE
sub.nYear =	@year
--sub.dtSubmitted > '2018-12-01 00:00:00.000'
and
gc.GroupId in ('PCC UK','PCC Offshore','SBA UK')

UNION ALL

SELECT

 p.refcode [Client Code]
,p.NAME [Surname / Pship Name]
,NULL
,p.TaxRef [Tax Reference]
,NULL
,psub.strUser [User Name]
,psub.dtSubmitted [Date and Time]
,psub.nYear [Tax Year]
,subref.strStatus [Status]
,gp.GroupId [Access Group]


FROM

 Partnership p

LEFT JOIN PartnershipFBISubmissions psub on psub.lPartnershipID = p.PClientid
LEFT JOIN GroupPartnership gp on gp.PClientid = p.PClientid
LEFT JOIN FBIStatusRef subref on subref.lID = psub.lStatusID

WHERE
psub.nYear =	@year
--psub.dtSubmitted > '2018-12-01 00:00:00.000'
and
gp.GroupId in ('PCC UK','PCC Offshore','SBA UK')



ORDER BY

[Date and Time]